import logging
logger = logging.getLogger('shopify_integration')
import time # Ensure you add this if it's missing at the very top of your file
import requests
from django.conf import settings
from core_api.models import Product
from .shopify_oauth import get_valid_access_token

def sync_shopify_catalog(connection):
    access_token = get_valid_access_token(connection)
    shop_domain = connection.store_identifier
    
    if settings.DEBUG and access_token.startswith("mock_"):
        # Mock mode: populate with 3 sample items
        items_data = [
            {"source_id": "mock_shop_item1", "title": "Band Hoodie", "sku": "HOODIE-M", "barcode": "333333333333"},
            {"source_id": "mock_shop_item2", "title": "Sticker Pack", "sku": "STICKERS", "barcode": "444444444444"},
            {"source_id": "mock_shop_item3", "title": "CD Album", "sku": "", "barcode": ""},
        ]
        
        for item in items_data:
            sku_or_barcode = item["barcode"] if item["barcode"] else item["sku"]
            has_missing_identifier = False
            if not sku_or_barcode:
                sku_or_barcode = f"MISSING-SHOPIFY-{item['source_id']}"
                has_missing_identifier = True
                
            Product.objects.update_or_create(
                connection=connection,
                sku_or_barcode=sku_or_barcode,
                defaults={
                    "title": item["title"],
                    "has_missing_identifier": has_missing_identifier,
                    "external_catalog_id": item["source_id"]
                }
            )
        return {"status": "success", "mode": "mock", "items_synced": len(items_data)}
        
# Real mode using Shopify GraphQL API
    url = f"https://{shop_domain}/admin/api/2024-01/graphql.json"
    headers = {
        "X-Shopify-Access-Token": access_token,
        "Content-Type": "application/json"
    }
    
    # Query updated to fetch variants directly. This bypasses the nested pagination cost limit 
    # (which was crashing the sync at 211) and guarantees every POS and Online product is fetched.
    # Also fetches featuredImage so product images can be stored and shown in the dashboard.
    query = """
    query getVariants($cursor: String) {
      productVariants(first: 100, after: $cursor) {
        pageInfo {
          hasNextPage
          endCursor
        }
        edges {
          node {
            id
            sku
            barcode
            title
            image {
              url
            }
            product {
              id
              title
              productType
              publishedAt
              featuredImage {
                url
              }
            }
          }
        }
      }
    }
    """
    
    synced_count = 0
    has_next_page = True
    cursor = None
    
    # Loop continuously until all pages of products have been downloaded
    while has_next_page:
        variables = {"cursor": cursor} if cursor else {}
        try:
            response = requests.post(url, headers=headers, json={"query": query, "variables": variables})
            response.raise_for_status()
            data = response.json()
        except Exception:
            # If network fails, wait 2 seconds and retry
            time.sleep(2)
            continue

        # Catch Shopify GraphQL Rate Limits (returns 200 OK but with errors)
        if "errors" in data and not data.get("data"):
            time.sleep(2) # Back off for 2 seconds to let the Shopify token bucket refill
            continue
            
        # Safely parse data (using 'or {}' prevents AttributeError crashes if data is null)
        response_data = data.get("data") or {}
        variants_data = response_data.get("productVariants") or {}
        edges = variants_data.get("edges") or []
        
        for edge in edges:
            var_node = edge.get("node") or {}
            product_node = var_node.get("product") or {}
            
            var_id_full = var_node.get("id", "")
            sku = var_node.get("sku") or ""
            barcode = var_node.get("barcode") or ""
            
            product_title = product_node.get("title", "Unknown Product")
            var_title = var_node.get("title", "")
            
            # 1. Determine the Channel
            # If Shopify provides a 'publishedAt' date, it is active on the Online Store. 
            # If it is null, it is POS-only.
            published_at = product_node.get("publishedAt")
            channel_value = "Online" if published_at else "POS"
            
            # Combine product title and variant title nicely (e.g., "Hoodie - Large")
            if var_title and var_title.lower() != "default title":
                final_title = f"{product_title} - {var_title}"
            else:
                final_title = product_title
                
            sku_or_barcode = barcode if barcode else sku
            has_missing_identifier = False
            
            if not sku_or_barcode:
                sku_or_barcode = f"MISSING-SHOPIFY-{var_id_full}"
                has_missing_identifier = True

            # Prefer the variant's own image if it has one, otherwise fall back to the
            # product's featured image. Both can be null depending on what's set in Shopify.
            variant_image = var_node.get("image") or {}
            product_image = product_node.get("featuredImage") or {}
            image_url = variant_image.get("url") or product_image.get("url")
                
            defaults_dict = {
                "title": final_title,
                "has_missing_identifier": has_missing_identifier,
                "external_catalog_id": var_id_full,
                "image_url": image_url
            }

            # Safely add the channel field if your Django model supports it
            if hasattr(Product, 'channel'):
                defaults_dict['channel'] = channel_value

            Product.objects.update_or_create(
                connection=connection,
                sku_or_barcode=sku_or_barcode,
                defaults=defaults_dict
            )
            synced_count += 1
        
# Check if there is another page of variants to fetch
        page_info = variants_data.get("pageInfo") or {}
        has_next_page = page_info.get("hasNextPage", False)
        cursor = page_info.get("endCursor")
            
    return {"status": "success", "mode": "live", "items_synced": synced_count}


def sync_recent_sales(connection):
    from core_api.utils.aria import get_current_aria_week_start
    from core_api.models import Product, Sale, get_default_verification_status
    from django.utils.dateparse import parse_datetime

    aria_start = get_current_aria_week_start()

    url = f"https://{connection.store_identifier}/admin/api/2024-01/orders.json"
    headers = {
        "X-Shopify-Access-Token": connection.access_token,
        "Content-Type": "application/json"
    }

    params = {
        "status": "any"
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        orders = response.json().get("orders", [])
        logger.info(f"Shopify sent {len(orders)} orders for {connection.store_identifier}")
    except Exception as e:
        logger.error(f"Failed to fetch orders for {connection.store_identifier}: {e}")
        return

    for order in orders:
        created_at_str = order.get('created_at')
        if not created_at_str:
            continue

        created_at_dt = parse_datetime(created_at_str)

        is_within_aria = True
        if created_at_dt and created_at_dt < aria_start:
            is_within_aria = False

        source_name = order.get('source_name', 'web')
        channel = 'POS' if source_name == 'pos' else 'ONLINE'
        order_id = str(order.get('id', ''))

        gateways = [g.lower() for g in order.get('payment_gateway_names', [])]
        if any('cash' in g for g in gateways):
            payment_type = 'CASH'
        elif any('gift_card' in g for g in gateways):
            payment_type = 'GIFT_CARD_REDEMPTION'
        elif any('manual' in g for g in gateways):
            payment_type = 'MANUAL_CARD_ENTRY'
        elif any(g in ['shopify_payments', 'stripe', 'paypal', 'bogus'] for g in gateways) or len(gateways) == 0:
            payment_type = 'CREDIT_CARD'
        else:
            payment_type = 'OTHER_USER_DEFINED'

        sale_channel = 'POS' if channel == 'POS' else 'WEBSTORE'
        is_presale = (sale_channel == 'WEBSTORE')

        line_items = order.get('line_items', [])
        for item in line_items:
            sku = item.get('sku', '')
            if not sku:
                logger.warning(f"Skipped order {order_id}: missing SKU")
                continue

            product = Product.objects.filter(connection=connection, sku_or_barcode=sku).first()
            if product:
                verification_status = get_default_verification_status(payment_type)
                verified_by = 'Shopify API' if verification_status == 'AUTO_VERIFIED' else None

                Sale.objects.update_or_create(
                    connection=connection,
                    external_order_id=order_id,
                    product=product,
                    defaults={
                        'sale_date': created_at_dt,
                        'system_location': 'Shopify POS' if channel == 'POS' else 'Shopify Webstore',
                        'sales_units': int(item.get('quantity', 1)),
                        'sale_channel': sale_channel,
                        'is_presale': is_presale,
                        'payment_type': payment_type,
                        'verification_status': verification_status,
                        'verified_by': verified_by,
                        'source_platform': 'Shopify',
                        'price': item.get('price', 0.0),
                        'is_within_current_aria_period': is_within_aria,
                    }
                )
                logger.info(f"Saved sale for order {order_id}, SKU: {sku}")
            else:
                logger.warning(f"Skipped order {order_id}: SKU '{sku}' not found in database")