from django.urls import path
from .views import (
    ShopifyConnectView, 
    ShopifyCallbackView, 
    ShopifyOrderWebhookView, 
    ProductsView,
    disconnect_shopify,
    ShopifyCustomerDataRequestView,
    ShopifyCustomerRedactView,
    ShopifyShopRedactView,
)

urlpatterns = [
    path('connect/', ShopifyConnectView.as_view(), name='shopify_connect'),
    path('callback/', ShopifyCallbackView.as_view(), name='shopify_callback'),
    path('webhooks/orders/', ShopifyOrderWebhookView.as_view(), name='shopify_webhook_orders'),

    # Compliance webhooks — registered WITH and WITHOUT a trailing slash.
    # Shopify's webhook delivery strips the trailing slash even when the
    # subscription URI in shopify.app.toml includes one, and Django's
    # APPEND_SLASH can't redirect a POST without losing the body, so both
    # forms must resolve directly to the same view.
    path('webhooks/customers/data_request/', ShopifyCustomerDataRequestView.as_view(), name='shopify_webhook_customer_data_request'),
    path('webhooks/customers/data_request', ShopifyCustomerDataRequestView.as_view(), name='shopify_webhook_customer_data_request_noslash'),

    path('webhooks/customers/redact/', ShopifyCustomerRedactView.as_view(), name='shopify_webhook_customer_redact'),
    path('webhooks/customers/redact', ShopifyCustomerRedactView.as_view(), name='shopify_webhook_customer_redact_noslash'),

    path('webhooks/shop/redact/', ShopifyShopRedactView.as_view(), name='shopify_webhook_shop_redact'),
    path('webhooks/shop/redact', ShopifyShopRedactView.as_view(), name='shopify_webhook_shop_redact_noslash'),

    path('synced-products/', ProductsView.as_view(), name='synced_products'),
    path('disconnect/', disconnect_shopify, name='disconnect_shopify'),
]